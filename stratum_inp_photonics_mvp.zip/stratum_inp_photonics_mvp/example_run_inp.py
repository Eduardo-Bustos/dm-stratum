from stratum.modules.inp_photonics.schema import InPObservation
from stratum.modules.inp_photonics.signals import classify_regime, decision_note

obs = InPObservation(
    date="2026-05-02",
    indium_feedstock_availability=0.55,
    zinc_output_proxy=0.65,
    recovery_rate_proxy=0.50,
    scrap_recycling_proxy=0.40,
    refining_capacity=0.45,
    geographic_diversification=0.30,
    export_control_inverse=0.25,
    logistics_access=0.70,
    concentration_index=0.52,
    substrate_capacity=0.38,
    epitaxy_capacity=0.32,
    yield_quality=0.70,
    lead_time_pressure_index=2.10,
    ai_optical_demand_pressure=1.60,
    control_layer_pressure=0.70,
    notes="Illustrative stress scenario, not live market data."
)

signal = classify_regime(obs, r_star_ai=0.78)
print(signal)
print(decision_note(signal))
