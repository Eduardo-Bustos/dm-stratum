from .schema import InPObservation

DEFAULT_WEIGHTS = {
    "upstream": {
        "indium_feedstock_availability": 0.40,
        "zinc_output_proxy": 0.25,
        "recovery_rate_proxy": 0.25,
        "scrap_recycling_proxy": 0.10,
    },
    "refining": {
        "refining_capacity": 0.45,
        "geographic_diversification": 0.25,
        "export_control_inverse": 0.20,
        "logistics_access": 0.10,
    },
    "photonics": {
        "substrate_capacity": 0.30,
        "epitaxy_capacity": 0.30,
        "yield_quality": 0.20,
        "lead_time_inverse": 0.20,
    },
}

def _clip01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))

def weighted_score(values: dict, weights: dict) -> float:
    return _clip01(sum(_clip01(values[k]) * w for k, w in weights.items()))

def theta_upstream(obs: InPObservation, weights=DEFAULT_WEIGHTS) -> float:
    return weighted_score({
        "indium_feedstock_availability": obs.indium_feedstock_availability,
        "zinc_output_proxy": obs.zinc_output_proxy,
        "recovery_rate_proxy": obs.recovery_rate_proxy,
        "scrap_recycling_proxy": obs.scrap_recycling_proxy,
    }, weights["upstream"])

def theta_refining(obs: InPObservation, weights=DEFAULT_WEIGHTS) -> float:
    return weighted_score({
        "refining_capacity": obs.refining_capacity,
        "geographic_diversification": obs.geographic_diversification,
        "export_control_inverse": obs.export_control_inverse,
        "logistics_access": obs.logistics_access,
    }, weights["refining"])

def theta_photonics(obs: InPObservation, weights=DEFAULT_WEIGHTS) -> float:
    lead_time_inverse = 1.0 / max(obs.lead_time_pressure_index, 0.01)
    return weighted_score({
        "substrate_capacity": obs.substrate_capacity,
        "epitaxy_capacity": obs.epitaxy_capacity,
        "yield_quality": obs.yield_quality,
        "lead_time_inverse": lead_time_inverse,
    }, weights["photonics"])

def theta_inp(obs: InPObservation, weights=DEFAULT_WEIGHTS) -> dict:
    l1 = theta_upstream(obs, weights)
    l2 = theta_refining(obs, weights)
    l3 = theta_photonics(obs, weights)
    theta = min(l1, l2, l3)

    bottleneck = min(
        [("upstream", l1), ("refining", l2), ("photonics", l3)],
        key=lambda x: x[1]
    )[0]

    return {
        "theta_upstream": l1,
        "theta_refining": l2,
        "theta_photonics": l3,
        "theta_inp": theta,
        "bottleneck_layer": bottleneck,
    }

def iobi(theta_value: float, stress: float = 0.35, floor: float = 0.15) -> float:
    if stress <= floor:
        raise ValueError("stress must be greater than floor")
    return (theta_value - floor) / (stress - floor)

def sg_ai(r_star_ai: float, theta_value: float) -> float:
    return float(r_star_ai) - float(theta_value)
