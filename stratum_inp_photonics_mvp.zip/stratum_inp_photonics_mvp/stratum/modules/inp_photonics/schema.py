from dataclasses import dataclass
from typing import Optional

@dataclass
class InPObservation:
    date: str

    # Layer 1: upstream
    indium_feedstock_availability: float
    zinc_output_proxy: float
    recovery_rate_proxy: float
    scrap_recycling_proxy: float

    # Layer 2: refining / processing
    refining_capacity: float
    geographic_diversification: float
    export_control_inverse: float
    logistics_access: float
    concentration_index: float

    # Layer 3: photonics / InP manufacturing
    substrate_capacity: float
    epitaxy_capacity: float
    yield_quality: float
    lead_time_pressure_index: float

    # Demand and control pressure
    ai_optical_demand_pressure: float
    control_layer_pressure: float = 0.0
    notes: Optional[str] = None
