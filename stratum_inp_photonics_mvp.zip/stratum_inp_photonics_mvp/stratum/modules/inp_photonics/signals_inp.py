from .schema import InPObservation
from .theta_inp import theta_inp, iobi, sg_ai

def classify_regime(
    obs: InPObservation,
    r_star_ai: float = 0.70,
    stress: float = 0.35,
    floor: float = 0.15,
    lead_time_stress: float = 1.50,
    lead_time_critical: float = 2.00,
    concentration_critical: float = 0.40,
    ai_demand_stress: float = 1.30,
) -> dict:
    theta_pack = theta_inp(obs)
    theta_value = theta_pack["theta_inp"]
    iobi_value = iobi(theta_value, stress=stress, floor=floor)
    sg_value = sg_ai(r_star_ai, theta_value)

    critical = iobi_value <= 0 or obs.lead_time_pressure_index >= lead_time_critical
    fragmentation = (
        critical
        and obs.concentration_index >= concentration_critical
        and obs.ai_optical_demand_pressure >= ai_demand_stress
    )

    if fragmentation:
        regime = "FRAGMENTATION"
    elif critical:
        regime = "CRITICAL"
    elif (0 < iobi_value <= 1) or obs.lead_time_pressure_index >= lead_time_stress:
        regime = "STRESS"
    else:
        regime = "NORMAL"

    return {
        **theta_pack,
        "iobi": iobi_value,
        "sg_ai": sg_value,
        "regime": regime,
        "lead_time_pressure_index": obs.lead_time_pressure_index,
        "ai_optical_demand_pressure": obs.ai_optical_demand_pressure,
        "concentration_index": obs.concentration_index,
    }

def decision_note(signal: dict) -> str:
    regime = signal["regime"]
    b = signal["bottleneck_layer"]
    if regime == "NORMAL":
        return f"Normal operating buffer. Monitor {b} as the current weakest layer."
    if regime == "STRESS":
        return f"Operational stress. {b} is constraining absorption capacity; monitor lead times and substitution risk."
    if regime == "CRITICAL":
        return f"Critical constraint. {b} is near or below operational floor; capacity allocation may become non-price based."
    return f"Fragmentation regime. {b} bottleneck plus demand pressure and concentration risk imply permissioned allocation."
