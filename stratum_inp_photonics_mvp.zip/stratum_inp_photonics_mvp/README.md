# STRATUM — AI Photonics / Indium–InP Constraint Module (MVP)

## Purpose
This module integrates the Indium → InP → AI Optical Infrastructure chain into STRATUM as a constraint-sensitive asset layer.

It follows the same decision logic used for oil inventories:
buffer → stress threshold → operational floor → velocity → days-to-constraint → regime shift.

## Core chain
Zinc/Copper ores → Indium recovery → Indium refining → InP substrates → Epitaxy/MOCVD → PICs/lasers → 800G/1.6T optical transceivers → AI data centers.

## Core variables
- upstream_buffer_index: availability of recoverable indium feedstock.
- refining_buffer_index: refining/purification capacity and concentration risk.
- photonics_buffer_index: InP substrate, epitaxy, yield and lead-time capacity.
- lead_time_pressure_index: current lead time / normal lead time.
- ai_optical_demand_pressure: current AI optical demand / baseline optical demand.
- control_layer_pressure: export controls, licensing, sanctions or geopolitical friction.

## Core equations
theta_inp = min(theta_upstream, theta_refining, theta_photonics)

IOBI = (theta_inp - floor) / (stress - floor)

SG_AI = R_star_AI - theta_inp

## Regimes
- NORMAL: IOBI > 1
- STRESS: 0 < IOBI <= 1 or lead_time_pressure_index >= 1.5
- CRITICAL: IOBI <= 0 or lead_time_pressure_index >= 2.0
- FRAGMENTATION: CRITICAL + high concentration/control-layer pressure + rising AI demand

## Suggested sources
- USGS Mineral Commodity Summaries: Indium
- USGS data release for indium production
- Public company filings: InP substrates, optical components, transceivers
- Industry reports: LightCounting, Yole, TrendForce, SEMI
- Hyperscaler capex and data-center optical upgrade cycles
