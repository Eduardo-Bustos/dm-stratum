# Technical Note

The strict condition is valid as a confirmation standard, but often not observable in real time because admissibility is endogenous.

STRATUM therefore models the pre-failure deformation:

```text
domain drift → functional-equivalence divergence → transaction-level confirmation
```

The EDI is a leading indicator, not a substitute for proof.
