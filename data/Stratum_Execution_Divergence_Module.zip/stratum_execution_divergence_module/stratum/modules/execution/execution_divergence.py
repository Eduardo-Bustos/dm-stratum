from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import json
import numpy as np
import pandas as pd
from scipy.special import expit

@dataclass
class ExecutionDivergenceConfig:
    cluster_cols: Tuple[str, ...] = ("asset_class", "route_or_market", "counterparty_tier")
    input_cols: Tuple[str, ...] = ("size", "price", "volatility", "spread", "risk_score")
    outcome_cols: Tuple[str, ...] = ("completion_time", "execution_cost", "delay_flag", "failure_flag")
    min_cluster_size: int = 5
    stress_threshold: float = 0.40
    critical_threshold: float = 0.70
    black_threshold: float = 0.85

def _safe_numeric(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce").replace([np.inf, -np.inf], np.nan)

def _zscore(s: pd.Series) -> pd.Series:
    x = _safe_numeric(s)
    sd = x.std(ddof=0)
    if pd.isna(sd) or sd == 0:
        return pd.Series(np.zeros(len(x)), index=x.index)
    return (x - x.mean()) / sd

def _robust_scale(s: pd.Series) -> pd.Series:
    x = _safe_numeric(s)
    med = x.median()
    mad = (x - med).abs().median()
    if pd.isna(mad) or mad == 0:
        return pd.Series(np.zeros(len(x)), index=x.index)
    return (x - med) / (1.4826 * mad)

def prepare_execution_data(df: pd.DataFrame, cfg: Optional[ExecutionDivergenceConfig] = None) -> pd.DataFrame:
    cfg = cfg or ExecutionDivergenceConfig()
    required = set(["date"]) | set(cfg.cluster_cols) | set(cfg.input_cols) | set(cfg.outcome_cols)
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    out = df.copy()
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    out = out.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)

    for col in cfg.input_cols + cfg.outcome_cols:
        out[col] = _safe_numeric(out[col])

    out["equivalence_cluster"] = out[list(cfg.cluster_cols)].astype(str).agg("|".join, axis=1)
    out["input_state_score"] = np.mean([_zscore(out[c]).fillna(0) for c in cfg.input_cols], axis=0)
    out["outcome_strain_score"] = np.mean([_robust_scale(out[c]).fillna(0) for c in cfg.outcome_cols], axis=0)
    return out

def classify_edi(edi: float, cfg: Optional[ExecutionDivergenceConfig] = None) -> str:
    cfg = cfg or ExecutionDivergenceConfig()
    if edi >= cfg.black_threshold:
        return "BLACK_EXECUTION_BREAKDOWN"
    if edi >= cfg.critical_threshold:
        return "RED_EXECUTION_DIVERGENCE"
    if edi >= cfg.stress_threshold:
        return "AMBER_DOMAIN_DRIFT"
    return "GREEN_LOCAL_EQUIVALENCE"

def compute_cluster_divergence(df: pd.DataFrame, cfg: Optional[ExecutionDivergenceConfig] = None) -> pd.DataFrame:
    cfg = cfg or ExecutionDivergenceConfig()
    data = prepare_execution_data(df, cfg)
    rows: List[Dict] = []

    for cluster, g in data.groupby("equivalence_cluster"):
        if len(g) < cfg.min_cluster_size:
            continue

        input_dispersion = float(g["input_state_score"].std(ddof=0))
        outcome_dispersion = float(g["outcome_strain_score"].std(ddof=0))
        failure_rate = float(g["failure_flag"].mean())
        delay_rate = float(g["delay_flag"].mean())
        cost_tail = float((g["execution_cost"] > g["execution_cost"].quantile(0.90)).mean())
        completion_tail = float((g["completion_time"] > g["completion_time"].quantile(0.90)).mean())

        raw_edi = (
            0.35 * max(0.0, outcome_dispersion - input_dispersion)
            + 0.25 * failure_rate
            + 0.20 * delay_rate
            + 0.10 * cost_tail
            + 0.10 * completion_tail
        )
        edi = float(expit(3.0 * (raw_edi - 0.35)))

        rows.append({
            "equivalence_cluster": cluster,
            "n": int(len(g)),
            "start_date": g["date"].min(),
            "end_date": g["date"].max(),
            "input_dispersion": round(input_dispersion, 6),
            "outcome_dispersion": round(outcome_dispersion, 6),
            "failure_rate": round(failure_rate, 6),
            "delay_rate": round(delay_rate, 6),
            "cost_tail": round(cost_tail, 6),
            "completion_tail": round(completion_tail, 6),
            "raw_edi": round(raw_edi, 6),
            "edi": round(edi, 6),
            "regime": classify_edi(edi, cfg),
        })

    return pd.DataFrame(rows).sort_values("edi", ascending=False).reset_index(drop=True) if rows else pd.DataFrame()

def compute_system_edi(cluster_df: pd.DataFrame) -> Dict:
    if cluster_df.empty:
        return {"system_edi": 0.0, "system_regime": "NO_DATA", "dominant_cluster": None, "high_priority_clusters": 0}
    weights = cluster_df["n"] / cluster_df["n"].sum()
    system_edi = float((cluster_df["edi"] * weights).sum())
    if system_edi >= 0.85:
        regime = "BLACK_EXECUTION_BREAKDOWN"
    elif system_edi >= 0.70:
        regime = "RED_EXECUTION_DIVERGENCE"
    elif system_edi >= 0.40:
        regime = "AMBER_DOMAIN_DRIFT"
    else:
        regime = "GREEN_LOCAL_EQUIVALENCE"
    return {
        "system_edi": round(system_edi, 6),
        "system_regime": regime,
        "dominant_cluster": cluster_df.iloc[0]["equivalence_cluster"],
        "high_priority_clusters": int((cluster_df["edi"] >= 0.70).sum()),
    }

def align_with_stratum_sg(system_edi: float, sg: float, theta: float) -> Dict:
    p_execution_binding = float(expit(4.0 * (system_edi + max(0.0, sg) - 0.75)))
    if sg > 0 and system_edi < 0.40:
        interpretation = "PRE_EXECUTION_DOMAIN_DRIFT"
    elif sg > 0 and system_edi >= 0.40:
        interpretation = "EXECUTION_LAYER_CONFIRMATION"
    elif sg <= 0 and system_edi >= 0.40:
        interpretation = "LOCAL_EXECUTION_STRESS_WITHOUT_SYSTEM_CONFIRMATION"
    else:
        interpretation = "NO_CONFIRMED_BREAKDOWN"
    return {
        "sg": round(float(sg), 6),
        "theta": round(float(theta), 6),
        "system_edi": round(float(system_edi), 6),
        "p_execution_binding": round(p_execution_binding, 6),
        "interpretation": interpretation,
    }

def run_execution_divergence_pipeline(csv_path: str, output_dir: str = "outputs", sg: float = 0.0, theta: float = 1.0) -> Dict:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(csv_path)
    clusters = compute_cluster_divergence(df)
    system = compute_system_edi(clusters)
    alignment = align_with_stratum_sg(system["system_edi"], sg=sg, theta=theta)

    clusters_path = out_dir / "execution_divergence_clusters.csv"
    summary_path = out_dir / "execution_divergence_summary.json"
    clusters.to_csv(clusters_path, index=False)

    summary = {
        "system": system,
        "alignment": alignment,
        "method_note": "This does not claim strict identical-input proof; it detects divergence under functional equivalence.",
        "clusters_output": str(clusters_path),
    }
    summary_path.write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    return summary
