# STRATUM Execution Divergence Module

This module tests whether functionally comparable transactions begin producing divergent completion outcomes.

It separates:

- strict confirmation: identical inputs + identical pathways + different outcomes;
- early warning: functional equivalence + rising conditional outcome dispersion.

Main indicator:

```text
EDI = Execution Divergence Index
```

Integration:

```text
SG = R* - Θ
```

If SG rises and EDI is still low: `PRE_EXECUTION_DOMAIN_DRIFT`.

If SG rises and EDI rises: `EXECUTION_LAYER_CONFIRMATION`.

Run:

```bash
pip install -r requirements.txt
python example_run_execution_divergence.py
```
