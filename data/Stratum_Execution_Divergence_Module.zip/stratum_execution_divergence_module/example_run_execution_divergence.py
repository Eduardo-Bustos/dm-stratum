from stratum.modules.execution.execution_divergence import run_execution_divergence_pipeline

summary = run_execution_divergence_pipeline(
    csv_path="data/execution_events_sample.csv",
    output_dir="outputs",
    sg=0.28,
    theta=0.62,
)
print(summary)
